var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');
var logs = require("./logger");
var fs = require("fs");
var auth = require("./auth");
var util = require("./util");


/*
   Get call to start the game
  @PARAM req: Request object
   @PARAM res: Response object
   @PARAM next: next object to go to next callback
  
   */

router.get('/start', function (req, res, next) {
  console.log("PARAM" + (req.query.user_name))
  try {
    var token = auth.createToken(req.query.user_name);
    var da = {};
    da[token] = {
      yellow: Array(7).fill(0)
      , red: new Array(7).fill(0)
    };
    da = JSON.stringify(da)
    fs.writeFile('./public/data.json', da, (err) => {
      if (err) throw err;
      if (!err) {
        logs.logger.info("CREATED")
        res.json({ token: token });
      }
    });
  }
  catch (err) {
    logs.logger.error(err);
    res.statusCode = "500";
    res.json({ message: "Internal server error" });
  }

});


/*
   Post call to store move
  @PARAM req: Request object
   @PARAM res: Response object
   @PARAM next: next object to go to next callback
  
   */
router.post("/move", auth.verify, (req, res, next) => {

  var column = req.body.column;
  console.log(req.body.column);
  if (column > 6 || column < 0) {
    logs.logger.error("Invalid Move,Invalid Column number");
    res.json({ status: "Invalid" });
  }
  else {

    if (util.checkMove(req, column)) {
      if (util.storMove(req.body.token, column) && util.checkWin(req.body.token, column)) {
        res.json({ status: "Win" });

      }
      else
        res.json({ status: "Valid" });

    }
    else
      res.json({ status: "Valid" });
  }

})


/*
   Delete call to end the game, also removes token
  @PARAM req: Request object
   @PARAM res: Response object
   @PARAM next: next object to go to next callback
  
   */
router.delete("/end", auth.verify, (req, res, next) => {

  try {
    fs.readFile('./public/data.json', (err, data) => {
      if (err) throw err;
      if (!err) {
        logs.logger.info("CREATED", data);
        var json_data = JSON.parse(data);
        json_data[req.body.token] = [];
        fs.writeFile('./public/data.json', JSON.stringify(json_data), (err, data) => {
          if (err) console.log(err);
          else console.log(("DATA"))
        })

      }

    });
  }
  catch (err) {
    logs.logger.error("ERROR" + err)
    console.log("ERRPR" + err)
  }

})
module.exports = router;
