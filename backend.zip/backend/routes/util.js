var fs = require("fs");
var logs = require("./logger");


/*
Util Lib for moves
*/
function Util() {

    /*
    checks whether move is valid or invalide
    @PARAM req: Request param
    @PARAM column: column user want to store
    @PARAM chance: chance,eg:red
    @Return bool: true/false
    */
    this.checkMove = (req, column, chance) => {
        try {
            console.log("UTIL");
            fs.readFile('./public/data.json', (err, data) => {
                if (err) throw err;
                if (!err) {
                    logs.logger.info("CREATED", data);
                    var json_data = JSON.parse(data);
                    if (chance === "red") {
                        console.log("RED" + json_data);

                        if (json_data[req.body.token][chance] && json_data[req.body.token]["red"] && json_data[req.body.token]["yellow"]) {
                            var red_moves = json_data[req.body.token]["red"];
                            var yellow_move = json_data[req.body.token]["yellow"];

                            if (red_moves[column] < 8) {
                                return true;
                            }
                        }
                    }

                }
            });
        }
        catch (err) {

            logs.logger.error("ERROR" + err)
            return false
        }
    },
     /*
    Store moves on is valid place
    @PARAM req: Request param
    @PARAM column: column user want to store
    @PARAM chance: chance,eg:red
    */

        this.storMove = (token, column, chance) => {
            try {
                fs.readFile('./public/data.json', (err, data) => {
                    if (err) throw err;
                    if (!err) {
                        logs.logger.info("CREATED", data);
                        var json_data = JSON.parse(data);
                        if (json_data[token] && json_data[token][chance] && json_data[token][chance][column])
                            json_data[token][chance][column]++;
                        console.log(json_data)
                        fs.writeFile('./public/data.json', JSON.stringify(json_data), (err, data) => {
                            if (err) console.log(err);
                            else console.log(("DATA"))
                        })

                    }

                });
            }
            catch (err) {
                logs.logger.error("ERROR" + err)
                console.log("ERRPR" + err)
            }
        },
        
        /*
    checks whether user won or not
    @PARAM req: Request param
    @PARAM chance: chance,eg:red
    @Return bool: true/false
    */
        this.checkWin = (token, chance) => {


            try {
                fs.readFile('./public/data.json', (err, data) => {
                    if (err) throw err;
                    if (!err) {
                        logs.logger.info("CREATED", data);
                        var json_data = JSON.parse(data);
                        var moves = json_data[token][chance];
                        for (var i = 0; i < moves.length - 4; i++) {

                            if (moves[i] == moves[i + 1] == moves[i + 1] == moves[i + 3]) {
                                return true
                            }
                            if (moves[i] == (moves[i + 1] - 1) == (moves[i + 1] - 2) == (moves[i + 3] - 3)) {
                                return true;
                            }

                        }
                        return false;

                    }

                });
            }
            catch (err) {
                logs.logger.error("ERROR" + err)
                console.log("ERRPR" + err)
            }


        }

}

module.emovesports = new Util();