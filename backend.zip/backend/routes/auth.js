var jwt = require('jsonwebtoken');
var logs = require("./logger");

function Auth() {

    /*
    Verifies user is authenticated or not
    @PARAM req: Request object
    @PARAM res: Response object
    @PARAM next: next object to go to next callback
   */
    this.verify = (req, res, next) => {
        jwt.verify(req.body.token, process.env.PRV_KEY, (err, decode) => {
            if (err) {
                logs.logger.error("ERRPR", err)
                next(err);
            }
            else {
                logs.logger.info("TOKEN VERIFIED");
                next();

            }
        })

    }

    /*
    Creates token for authentication
   @PARAM req: Request param
   @PARAM column: column user want to store
   @PARAM chance: chance,eg:red
   @Return bool: true/false
   */
    this.createToken = (user_name) => {
        console.log(process.env.PRV_KEY, user_name)
        if (user_name) {
            var token = jwt.sign({ user_name: user_name }, process.env.PRV_KEY);
            logs.logger.info("TOKEN CREATED");
            return token;
        }
        else throw "Invalid Username!";
    }
}


module.exports = new Auth();